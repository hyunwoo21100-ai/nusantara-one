# NUSANTARA ONE (N1)

Starter project Android native (Kotlin + WebView) untuk aplikasi N1.

## Membuat APK melalui GitHub Actions
1. Upload seluruh isi folder proyek ini ke repository GitHub `nusantara-one` (termasuk folder `.github`).
2. Pastikan file berada di root repository: `build.gradle`, `settings.gradle`, `app/`, dan `.github/`.
3. Buka tab Actions di GitHub, pilih workflow `Build N1 APK`, lalu tekan Run workflow.
4. Setelah selesai, buka hasil workflow dan unduh artifact `N1-debug-APK`. Ekstrak ZIP artifact untuk memperoleh `app-debug.apk`.

## Catatan
Ini adalah versi awal/prototipe. Konten Indonesia belum merupakan ensiklopedia lengkap dan pilihan "Kebanggaan Hari Ini" memakai empat contoh awal yang berganti harian; belum ada layanan editorial/live yang menjamin setiap hari selalu ada pencapaian baru. Login Google belum diaktifkan. Untuk mengaktifkannya perlu konfigurasi Firebase/Google OAuth dan pengujian aplikasi.
